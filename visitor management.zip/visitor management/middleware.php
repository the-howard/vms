<?php
session_start();
include_once('config.php');

// If user is NOT logged in, redirect them to login page
if (!isset($_SESSION['user'])) {
    header("location: " . BASE_URL . "login.php");
    exit();
}

// If user is logged in and this user is NOT an admin user, redirect them to landing page
if (isset($_SESSION['user']) && is_null($_SESSION['user']['role_id'])) {
    header("location: " . BASE_URL . "index.php");
    exit();
}

// Checks if logged in admin user can update post
function canUpdatePost($post_id = null)
{
    global $pdo;

    $user_id = $_SESSION['user']['id']; // Use the user ID from the session

    if (in_array(['permission_name' => 'update-post'], $_SESSION['userPermissions'])) {
        if ($_SESSION['user']['role'] === "Author") { // Author can update only posts that they themselves created
            $sql = "SELECT user_id FROM posts WHERE id=?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$post_id]);
            $post_result = $stmt->fetch(PDO::FETCH_ASSOC);
            $post_user_id = $post_result['user_id'];

            // If current user is the author of the post, then they can update the post
            if ($post_user_id === $user_id) {
                return true;
            } else { // If post is not created by this author
                return false;
            }
        } else { // If user is not author
            return true;
        }
    } else {
        return false;
    }
}

// Accepts user id and post id and checks if user can publish/unpublish a post
function canPublishPost()
{
    if (in_array(['permission_name' => 'publish-post'], $_SESSION['userPermissions'])) {
        return true;
    } else {
        return false;
    }
}

function canDeletePost()
{
    if (in_array(['permission_name' => 'delete-post'], $_SESSION['userPermissions'])) {
        return true;
    } else {
        return false;
    }
}

function canCreateUser()
{
    if (in_array(['permission_name' => 'create-user'], $_SESSION['userPermissions'])) {
        return true;
    } else {
        return false;
    }
}

function canUpdateUser()
{
    if (in_array(['permission_name' => 'update-user'], $_SESSION['userPermissions'])) {
        return true;
    } else {
        return false;
    }
}

function canDeleteUser()
{
    if (in_array(['permission_name' => 'delete-user'], $_SESSION['userPermissions'])) {
        return true;
    } else {
        return false;
    }
}

function canCreateRole($role_id)
{
    if (in_array(['permission_name' => 'create-role'], $_SESSION['userPermissions'])) {
        return true;
    } else {
        return false;
    }
}

function canUpdateRole($role_id)
{
    if (in_array(['permission_name' => 'update-role'], $_SESSION['userPermissions'])) {
        return true;
    } else {
        return false;
    }
}

function canDeleteRole()
{
    if (in_array(['permission_name' => 'delete-role'], $_SESSION['userPermissions'])) {
        return true;
    } else {
        return false;
    }
}

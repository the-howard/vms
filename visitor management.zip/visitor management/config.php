<?php
session_start(); // start session

// Database connection variables
$host = "localhost";
$dbname = "visitor_accounts";
$username = "howard";
$password = "your_db_password";

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);

    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Display success message
   // echo "Connected successfully";
} catch (PDOException $e) {
    // Handle connection errors
    die("Connection failed: " . $e->getMessage());
}
// define global constants
define('ROOT_PATH', realpath(dirname(__FILE__))); // path to the root folder
define('INCLUDE_PATH', realpath(dirname(__FILE__) . '/includes')); // Path to includes folder
define('BASE_URL', 'https://howardandblackray.icu/'); // the home url of the website

if (!function_exists('getMultipleRecords')) {
    function getMultipleRecords($sql, $params = [])
    {
        global $pdo;
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $stmt->closeCursor(); // optional: close cursor explicitly
        return $records;
    }
}

if (!function_exists('getSingleRecord')) {
    function getSingleRecord($sql, $params = [])
    {
        global $pdo;
        if (!is_array($params)) {
            $params = [$params];
        }
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $record = $stmt->fetch(PDO::FETCH_ASSOC);
        $stmt->closeCursor(); // optional: close cursor explicitly
        return $record;
    }
}

if (!function_exists('modifyRecord')) {
    function modifyRecord($sql, $params = [])
    {
        global $pdo;
        if (!is_array($params)) {
            $params = [$params];
        }
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute($params);
        $stmt->closeCursor(); // optional: close cursor explicitly
        return $result;
    }
}

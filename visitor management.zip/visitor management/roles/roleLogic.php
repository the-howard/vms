<?php
$role_id = 0;
$name = "";
$description = "";
$isEditing = false;
$roles = array();
$errors = array();

include_once('../../config.php'); // Make sure this line includes the config file

// ACTION: update role
if (isset($_POST['update_role'])) {
    $role_id = $_POST['role_id'];
    updateRole($role_id);
}
// ACTION: Save Role
if (isset($_POST['save_role'])) {
    saveRole();
}
// ACTION: fetch role for editing
if (isset($_GET["edit_role"])) {
    $role_id = $_GET['edit_role'];
    editRole($role_id);
}
// ACTION: Delete role
if (isset($_GET['delete_role'])) {
    $role_id = $_GET['delete_role'];
    deleteRole($role_id);
}

// Save role to database
function saveRole()
{
    global $pdo, $errors, $name, $description;
    $errors = validateRole($_POST, ['save_role']);
    if (count($errors) === 0) {
        // receive form values
        $name = $_POST['name'];
        $description = $_POST['description'];

        // Prepare the SQL statement
        $sql = "INSERT INTO roles (name, description) VALUES (?, ?)";
        $stmt = $pdo->prepare($sql);

        // Bind parameters and execute the statement
        $stmt->execute([$name, $description]);

        // Check if the insertion was successful
        if ($stmt->rowCount() > 0) {
            $_SESSION['success_msg'] = "Role created successfully";
            header("location: " . BASE_URL . "admin/roles/roleList.php");
            exit();
        } else {
            $_SESSION['error_msg'] = "Something went wrong. Could not save role in Database";
        }
    }
}

// Update role in the database
function updateRole($role_id)
{
    global $pdo, $errors, $name, $description;
    $errors = validateRole($_POST, ['update_role']);
    if (count($errors) === 0) {
        // receive form values
        $name = $_POST['name'];
        $description = $_POST['description'];

        // Prepare the SQL statement
        $sql = "UPDATE roles SET name=?, description=? WHERE id=?";
        $stmt = $pdo->prepare($sql);

        // Bind parameters and execute the statement
        $stmt->execute([$name, $description, $role_id]);

        // Check if the update was successful
        if ($stmt->rowCount() > 0) {
            $_SESSION['success_msg'] = "Role successfully updated";
            $isEditing = false;
            header("location: " . BASE_URL . "admin/roles/roleList.php");
            exit();
        } else {
            $_SESSION['error_msg'] = "Something went wrong. Could not update role in Database";
        }
    }
}

// Fetch role data for editing
function editRole($role_id)
{
    global $pdo, $name, $description, $isEditing;

    // Prepare the SQL statement
    $sql = "SELECT * FROM roles WHERE id=?";
    $stmt = $pdo->prepare($sql);

    // Bind parameters and execute the statement
    $stmt->execute([$role_id]);

    // Fetch the role data
    $role = $stmt->fetch(PDO::FETCH_ASSOC);

    // Assign fetched data to variables
    $role_id = $role['id'];
    $name = $role['name'];
    $description = $role['description'];
    $isEditing = true;
}

// Delete role from the database
function deleteRole($role_id)
{
    global $pdo;

    // Prepare the SQL statement
    $sql = "DELETE FROM roles WHERE id=?";
    $stmt = $pdo->prepare($sql);

    // Bind parameters and execute the statement
    $stmt->execute([$role_id]);

    // Check if the deletion was successful
    if ($stmt->rowCount() > 0) {
        $_SESSION['success_msg'] = "Role trashed!!";
        header("location: " . BASE_URL . "admin/roles/roleList.php");
        exit();
    }
}

// Fetch all roles from the database
function getAllRoles()
{
    global $pdo;

    // Prepare the SQL statement
    $sql = "SELECT id, name FROM roles";
    $stmt = $pdo->query($sql);

    // Fetch all roles
    $roles = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $roles;
}

// Fetch all permissions from the database
function getAllPermissions()
{
    global $pdo;

    // Prepare the SQL statement
    $sql = "SELECT * FROM permissions";
    $stmt = $pdo->query($sql);

    // Fetch all permissions
    $permissions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $permissions;
}

// Fetch all permissions for a specific role from the database
function getRoleAllPermissions($role_id)
{
    global $pdo;

    // Prepare the SQL statement
    $sql = "SELECT permissions.* FROM permissions
            JOIN permission_role
              ON permissions.id = permission_role.permission_id
            WHERE permission_role.role_id=?";
    $stmt = $pdo->prepare($sql);

    // Bind parameters and execute the statement
    $stmt->execute([$role_id]);

    // Fetch all permissions for the role
    $permissions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $permissions;
}

// Save permissions for a role in the database
function saveRolePermissions($permission_ids, $role_id)
{
    global $pdo;

    // Delete existing permissions for the role
    $sql_delete = "DELETE FROM permission_role WHERE role_id=?";
    $stmt_delete = $pdo->prepare($sql_delete);
    $stmt_delete->execute([$role_id]);

    // Insert new permissions for the role
    foreach ($permission_ids as $id) {
        $sql_insert = "INSERT INTO permission_role (role_id, permission_id) VALUES (?, ?)";
        $stmt_insert = $pdo->prepare($sql_insert);
        $stmt_insert->execute([$role_id, $id]);
    }

    $_SESSION['success_msg'] = "Permissions saved";
    header("location: roleList.php");
    exit();
}
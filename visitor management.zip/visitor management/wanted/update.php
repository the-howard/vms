<?php
include_once('../../config.php');

session_start();
$user = $_SESSION["user"];
$id = $_GET['id'];

$sql = "SELECT * FROM wanted_people WHERE id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$id]);
$person = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $surname = $_POST['surname'];
    $first_name = $_POST['first_name'];
    $gender = $_POST['gender'];
    $id_pp_no = $_POST['id_pp_no'];
    $place_of_birth = $_POST['place_of_birth'];
    $nationality = $_POST['nationality'];
    $height = $_POST['height'];
    $complexion = $_POST['complexion'];
    $hair_color = $_POST['hair_color'];
    $eye_color = $_POST['eye_color'];
    $languages_spoken = $_POST['languages_spoken'];
    $charges = $_POST['charges'];
    $description = $_POST['description'];

    if ($_FILES['image']['name']) {
        $image = $_FILES['image']['name'];
        $target = "images/" . basename($image);
        move_uploaded_file($_FILES['image']['tmp_name'], $target);
    } else {
        $image = $person['image'];
    }

    $sql = "UPDATE wanted_people SET surname = ?, first_name = ?, gender = ?, id_pp_no = ?, place_of_birth = ?, nationality = ?, height = ?, complexion = ?, hair_color = ?, eye_color = ?, languages_spoken = ?, charges = ?, description = ?, image = ? WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$surname, $first_name, $gender, $id_pp_no, $place_of_birth, $nationality, $height, $complexion, $hair_color, $eye_color, $languages_spoken, $charges, $description, $image, $id]);

    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Edit Wanted Person</title>
</head>

<body>
    <h2>Edit Wanted Person</h2>
    <form method="POST" enctype="multipart/form-data">
        Surname: <input type="text" name="surname" value="<?= $person['surname'] ?>" required><br>
        First name: <input type="text" name="first_name" value="<?= $person['first_name'] ?>" required><br>
        Gender: <input type="text" name="gender" value="<?= $person['gender'] ?>" required><br>
        ID/PP No.: <input type="text" name="id_pp_no" value="<?= $person['id_pp_no'] ?>" required><br>
        Place of birth: <input type="text" name="place_of_birth" value="<?= $person['place_of_birth'] ?>" required><br>
        Nationality: <input type="text" name="nationality" value="<?= $person['nationality'] ?>" required><br>
        Height: <input type="text" name="height" value="<?= $person['height'] ?>" required><br>
        Complexion: <input type="text" name="complexion" value="<?= $person['complexion'] ?>" required><br>
        Hair color: <input type="text" name="hair_color" value="<?= $person['hair_color'] ?>" required><br>
        Eye color: <input type="text" name="eye_color" value="<?= $person['eye_color'] ?>" required><br>
        Languages spoken: <input type="text" name="languages_spoken" value="<?= $person['languages_spoken'] ?>" required><br>
        Charges: <input type="text" name="charges" value="<?= $person['charges'] ?>" required><br>
        Description: <textarea name="description" required><?= $person['description'] ?></textarea><br>
        Image: <input type="file" name="image"><br>
        <img src="images/<?= $person['image'] ?>" width="100"><br>
        <input type="submit" value="Update">
    </form>
</body>

</html>
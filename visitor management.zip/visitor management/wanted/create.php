<?php
// Enable error reporting
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

include_once('../../config.php');
require_once '../middleware.php';
include_once(INCLUDE_PATH . '/logic/common_functions.php');


session_start();
$user = $_SESSION["user"];


$displayError = ''; // Initialize the error message

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $surname = $_POST['surname'];
    $first_name = $_POST['first_name'];
    $gender = $_POST['gender'];
    $id_pp_no = $_POST['id_pp_no'];
    $place_of_birth = $_POST['place_of_birth'];
    $nationality = $_POST['nationality'];
    $height = $_POST['height'];
    $complexion = $_POST['complexion'];
    $hair_color = $_POST['hair_color'];
    $eye_color = $_POST['eye_color'];
    $languages_spoken = $_POST['languages_spoken'];
    $charges = $_POST['charges'];
    $image = $_FILES['image']['name'];
    $target = "images/" . basename($image);

    // Check for upload errors
    if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        echo "Failed to upload image. Error code: " . $_FILES['image']['error'];
        exit();
    }

    // Attempt to move the uploaded file
    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
        // Insert data into the database
        $sql = "INSERT INTO wanted_people (surname, first_name, gender, id_pp_no, place_of_birth, nationality, height,
complexion, hair_color, eye_color, languages_spoken, charges, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $surname, $first_name, $gender, $id_pp_no, $place_of_birth, $nationality, $height, $complexion,
            $hair_color, $eye_color, $languages_spoken, $charges, $image
        ]);

        // Redirect to the index page after successful upload and insertion
        header("Location: index.php");
        exit();
    } else {
        // Display additional error information if the move fails
        echo "Failed to move uploaded file to target directory. Check directory permissions.";
        exit();
    }
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>Add Wanted Person</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <style>
    /* Add your custom styles here */
    </style>

</head>

<body>
    <div class="navbar">
        <a href="index.php">Home</a>
        <a href="create.php">Add New</a>
        <a href="../dashboard.php">Dashboard</a>
        <a ref="logout.php">Logout</a>
    </div>
    <h2>Add Wanted Person</h2>
    <form method="POST" enctype="multipart/form-data">
        <!-- Identity Particulars -->
        <h3>Identity Particulars</h3>
        Surname: <input type="text" name="surname" required><br>
        Other Names: <input type="text" name="first_name" required><br>
        Gender: <input type="radio" name="gender" value="Male" required> Male
        <input type="radio" name="gender" value="Female" required> Female<br>
        ID/PP NO.: <input type="text" name="id_pp_no" required><br>
        Place of Birth: <input type="text" name="place_of_birth" required><br>

        <!-- Nationality & Physical Description -->
        <h3>Nationality & Physical Description</h3>
        Nationality: <input type="text" name="nationality" required><br>
        Height: <input type="text" name="height" required><br>
        Complexion: <input type="text" name="complexion" required><br>
        Hair Color: <input type="text" name="hair_color" required><br>
        Eye Color: <input type="text" name="eye_color" required><br>
        Languages Spoken: <input type="text" name="languages_spoken" required><br>

        <!-- Charges -->
        Charges: <input type="text" name="charges" required><br>

        <!-- Upload Image -->
        Image: <input type="file" name="image" required><br>

        <!-- Submit Button -->
        <input type="submit" value="Add">
    </form>
</body>

</html>
<?php
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

include_once('../../config.php');

require_once '../middleware.php';

session_start();
$user = $_SESSION["user"];

$sql = "SELECT * FROM wanted_people";
$stmt = $pdo->query($sql);
$people = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Wanted People</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
    /* Custom Styles */
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f8f9fa;
        /* light gray background */
    }

    .navbar {
        overflow: hidden;
        background-color: #333;
        /* dark gray background for navbar */
    }

    .navbar a {
        float: left;
        display: block;
        color: #f2f2f2;
        text-align: center;
        padding: 14px 20px;
        text-decoration: none;
    }

    .navbar a:hover {
        background-color: #ddd;
        /* light gray background on hover */
        color: black;
    }

    h2 {
        margin-top: 20px;
        /* add space above h2 */
        color: #333;
        /* dark gray text */
        text-align: center;
    }

    .card-container {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        padding: 20px;
        /* spacing around container */
    }

    .card {
        background-color: #fff;
        border: 1px solid #ddd;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        /* drop shadow */
        margin: 20px;
        /* space between cards */
        width: 300px;
        padding: 20px;
        text-align: center;
    }

    .card img {
        max-width: 100%;
        border-radius: 8px;
        margin-bottom: 10px;
    }

    .card h3 {
        color: #333;
        /* dark gray text */
    }

    .card p {
        color: #666;
        /* light gray text */
    }

    .card .actions {
        margin-top: 10px;
    }

    .card .actions a {
        text-decoration: none;
        color: #007bff;
        /* blue text */
        margin: 0 5px;
    }

    .card .actions a:hover {
        color: #0056b3;
        /* darker blue on hover */
    }
    </style>
</head>

<body>
    <div class="navbar">
        <a href="index.php">Home</a>
        <a href="create.php">Add New</a>
    </div>
    <h2>Wanted People</h2>
    <div class="card-container">
        <?php foreach ($people as $person) : ?>
        <div class="card">
            <a href="person_detail.php?id=<?= htmlspecialchars($person['id'] ?? '') ?>">
                <img src="images/<?= htmlspecialchars($person['image'] ?? '') ?>"
                    alt="<?= htmlspecialchars($person['name'] ?? '') ?>">
            </a>
            <h3><?= htmlspecialchars($person['surname'] ?? '') . ' ' . htmlspecialchars($person['first_name'] ?? '') ?>
            </h3>
            <p>Gender: <?= htmlspecialchars($person['gender'] ?? '') ?></p>
            <p>ID/PP No.: <?= htmlspecialchars($person['id_pp_no'] ?? '') ?></p>
            <p>Place of Birth: <?= htmlspecialchars($person['place_of_birth'] ?? '') ?></p>
            <h3>Nationality</h3>
            <p><?= htmlspecialchars($person['nationality'] ?? '') ?></p>
            <h3>Physical Description</h3>
            <p>Height: <?= htmlspecialchars($person['height'] ?? '') ?></p>
            <p>Complexion: <?= htmlspecialchars($person['complexion'] ?? '') ?></p>
            <p>Color of Hair: <?= htmlspecialchars($person['hair_color'] ?? '') ?></p>
            <p>Color of Eyes: <?= htmlspecialchars($person['eye_color'] ?? '') ?></p>
            <p>Languages Spoken: <?= htmlspecialchars($person['languages_spoken'] ?? '') ?></p>
            <h3>Charges</h3>
            <p><?= htmlspecialchars($person['charges'] ?? '') ?></p>
            <div class="actions">
                <a href="update.php?id=<?= htmlspecialchars($person['id'] ?? '') ?>">Edit</a>
                <a href="delete.php?id=<?= htmlspecialchars($person['id'] ?? '') ?>"
                    onclick="return confirm('Are you sure?')">Delete</a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</body>

</html>
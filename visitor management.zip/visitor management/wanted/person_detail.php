<?php
include_once('../../config.php');
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

session_start();
$user = $_SESSION["user"];
$id = $_GET['id'];
$sql = "SELECT * FROM wanted_people WHERE id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$id]);
$person = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$person) {
    echo "Person not found.";
    exit();
}
?>

<!DOCTYPE html>
<html>

<head>
    <title><?= htmlspecialchars($person['name'] ?? '') ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.min.css">
    <style>
    /* Custom Styles for Detail Page */
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f8f9fa;
        /* light gray background */
    }

    .navbar {
        overflow: hidden;
        background-color: #333;
        /* dark gray background for navbar */
    }

    .navbar a {
        float: left;
        display: block;
        color: #f2f2f2;
        text-align: center;
        padding: 14px 20px;
        text-decoration: none;
    }

    .navbar a:hover {
        background-color: #ddd;
        /* light gray background on hover */
        color: black;
    }

    .container {
        width: 80%;
        margin: 0 auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        margin-top: 20px;
    }

    h2 {
        color: #333;
    }

    p {
        color: #666;
    }

    img {
        max-width: 100%;
        border-radius: 8px;
        margin-bottom: 20px;
    }
    </style>
</head>

<body>
    <div class="navbar">
        <a href="index.php">Home</a>
        <a href="create.php">Add New</a>
    </div>
    <div class="container">
        <a href="images/<?= htmlspecialchars($person['image'] ?? '') ?>" data-lightbox="wanted-people"
            data-title="<?= htmlspecialchars($person['name'] ?? '') ?>">
            <img src="images/<?= htmlspecialchars($person['image'] ?? '') ?>"
                alt="<?= htmlspecialchars($person['name'] ?? '') ?>">
        </a>
        <p><?= htmlspecialchars($person['description'] ?? '') ?></p>
        <h2><?= htmlspecialchars($person['surname'] ?? '') . ' ' . htmlspecialchars($person['first_name'] ?? '') ?></h2>
        <p>Gender: <?= htmlspecialchars($person['gender'] ?? '') ?></p>
        <p>ID/PP No.: <?= htmlspecialchars($person['id_pp_no'] ?? '') ?></p>
        <p>Place of Birth: <?= htmlspecialchars($person['place_of_birth'] ?? '') ?></p>
        <h3>Nationality</h3>
        <p><?= htmlspecialchars($person['nationality'] ?? '') ?></p>
        <h3>Physical Description</h3>
        <p>Height: <?= htmlspecialchars($person['height'] ?? '') ?></p>
        <p>Complexion: <?= htmlspecialchars($person['complexion'] ?? '') ?></p>
        <p>Color of Hair: <?= htmlspecialchars($person['hair_color'] ?? '') ?></p>
        <p>Color of Eyes: <?= htmlspecialchars($person['eye_color'] ?? '') ?></p>
        <p>Languages Spoken: <?= htmlspecialchars($person['languages_spoken'] ?? '') ?></p>
        <h3>Charges</h3>
        <p><?= htmlspecialchars($person['charges'] ?? '') ?></p>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>
</body>

</html>
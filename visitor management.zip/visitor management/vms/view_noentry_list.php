<?php
// Enable error reporting
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

include_once('../../config.php');
require_once '../middleware.php';
session_start();
$user = $_SESSION['user'] ?? null;

$displayError = '';
$noEntryVisitors = [];

try {
    $stmt = $pdo->prepare("SELECT ne.IDNo, iv.Name, iv.Contact, ne.added_by, ne.added_at 
                           FROM no_entry_list ne 
                           JOIN info_visitor iv ON ne.IDNo = iv.IDNo");
    $stmt->execute();
    $noEntryVisitors = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $ex) {
    $displayError = "Error: " . $ex->getMessage();
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Visitor Management</title>
    <link rel="stylesheet" href="BootStrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
    <link rel="stylesheet" type="text/css" href="navbar3.css">
    <script src="BootStrap/js/jQuery.min.js"></script>
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" />
    <!-- Custom styles -->
    <link rel="stylesheet" href="../../assets/css/style.css">
    <script src="BootStrap/js/bootstrap.min.js"></script>
    <style>
    .form-container {
        max-height: 400px;
        overflow-y: auto;
    }
    </style>
</head>

<body>
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="../dashboard.php" id="li"><?php echo $_SESSION['user']['username']; ?></a>
            </div>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="front.php" id="li">Home</a></li>
                <li><a href="myform.php">Add Visitor</a></li>
                <li><a id="li" href="logoutform.php">Checked Out Visitors</a></li>
                <li><a id="li" href="query_data.php">View Data</a></li>
                <li><a id="li" href="view_reported_visitors.php">Reported Visitors</a></li>
                <li><a id="li" href="report_visitor.php">Report Visitor</a></li>
                <li><a id="li" href="view_noentry_list.php">No Entry Visitors</a></li>
                <li><a id="li" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <h2>No Entry List</h2>
        <?php if ($displayError) : ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($displayError); ?></div>
        <?php endif; ?>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID No</th>
                    <th>Visitor Name</th>
                    <th>Contact</th>
                    <th>Added By</th>
                    <th>Added At</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($noEntryVisitors)) : ?>
                <tr>
                    <td colspan="5">No visitors found on the no entry list.</td>
                </tr>
                <?php else : ?>
                <?php foreach ($noEntryVisitors as $visitor) : ?>
                <tr>
                    <td><?php echo htmlspecialchars($visitor['IDNo']); ?></td>
                    <td><?php echo htmlspecialchars($visitor['Name']); ?></td>
                    <td><?php echo htmlspecialchars($visitor['Contact']); ?></td>
                    <td><?php echo htmlspecialchars($visitor['added_by']); ?></td>
                    <td><?php echo htmlspecialchars($visitor['added_at']); ?></td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>

</html>
<?php
// Enable error reporting
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

// Start session
session_start();
$user = $_SESSION["user"];
require_once('front.php');
include_once('../../config.php');

/*if ($_SESSION["loggedIn"] == 0) {
    header("location: index.php");
    exit; // Add exit here
}*/

// Check if the session variable 'rid' is set
if (!isset($_POST['rid'])) {
    echo "Receipt ID is not set.";
    exit;
}

// Retrieve the ReceiptID from the POST array
$r_id = $_POST['rid'];

// Include database connection
require_once('../../conn.php');

try {
    // Create a PDO instance
    $pdo = new PDO('mysql:host=' . $server . ';dbname=' . $dbName, $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Prepare and execute SQL query
    $sql = "SELECT * FROM info_visitor WHERE ReceiptID = :r_id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':r_id', $r_id, PDO::PARAM_INT);
    $stmt->execute();

    // Check if the query returned any results
    if ($stmt->rowCount() > 0) {
        // Fetch the result using PDO methods
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
    } else {
        echo "No record found for ReceiptID: $r_id";
        exit;
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit;
}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>User Profile</title>
    <link rel="stylesheet" type="text/css" href="navbar3.css">
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
    <link rel="stylesheet" href="BootStrap/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="BootStrap/js/bootstrap.min.js"></script>
    <style>
    /* Your CSS styles here */
    #col-1 {
        margin-left: -10%;
    }

    span {
        text-underline-position: right;
        font-size: 20px;
    }

    @media print {

        /* style sheet for print goes here */
        .hide-from-printer {
            display: none;
        }
    }

    .row {
        margin-top: 5%;
        margin-left: 20%;
    }

    @page {
        size: 57mm 500mm;
        /* Width is 57mm, length can be adjusted based on the content */
        margin: 0;
        /* No margins */
    }

    body {
        font-family: Arial, sans-serif;
        font-size: 8pt;
        /* Adjust font size as needed */
        margin: 0;
        padding: 0;
    }

    .receipt {
        width: 57mm;
        margin: 0 auto;
        /* Center the receipt on the page */
        /* Add additional styling for your receipt content */
    }
    </style>
</head>

<body>
    <br><br><br>
    <div class="container">
        <br><br><br>
        <div class="row">
            <div class="col-sm-8">
                <p>Date: <?php echo $result['Date']; ?></p>
                <br>
                <p>Time in: <?php echo $result['TimeIN'] ?></p>
                <br>
                <span>Name: <?php echo $result['Name']; ?></span><br>
                <span>Contact No: <?php echo $result['Contact'] ?><br>
                    <span>Purpose: <?php echo $result['Purpose']; ?></span><br>
                    <span>Meeting: <?php echo $result['meetingTo']; ?></span><br>
                    <span>Receipt ID: <?php echo $result['ReceiptID']; ?></span><br>
                    <span>Comment: <?php echo $result['Comment']; ?></span><br>
                    <p><?php echo "Served by : " . $user; ?></p>
            </div>
        </div>
        <p style="text-align:center;padding-top:20px;">This badge is only valid for a limited time</p><br>
        <div>
            <button type="button" id="print-button" class="btn btn-primary hide-from-printer"
                onclick="printBadge()">Print
                Badge</button>
            <a type="button" id="back-button" class="btn btn-secondary hide-from-printer" href="front.php">Back</a>
        </div>
    </div>

    <script>
    function printBadge() {
        // Hide the "Print Badge" and "Back" buttons before printing
        document.getElementById("print-button").style.display = "none";
        document.getElementById("back-button").style.display = "none";

        // Print the page
        window.print();

        // Restore the visibility of the buttons after printing
        document.getElementById("print-button").style.display = "block";
        document.getElementById("back-button").style.display = "block";
    }
    </script>
</body>

</html>
<?php
// Enable error reporting
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

include_once('../../config.php');
require_once '../middleware.php';
session_start();
$user = $_SESSION['user'] ?? null;

$displayError = '';
$reportedVisitors = [];

try {
    $stmt = $pdo->prepare("SELECT bv.report_id, iv.Name, iv.IDNo, iv.Contact, iv.Purpose, bv.reason, bv.reported_by, bv.reported_at 
                           FROM reports bv 
                           JOIN info_visitor iv ON bv.visitor_id = iv.Serial");
    $stmt->execute();
    $reportedVisitors = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $ex) {
    $displayError = "Error: " . $ex->getMessage();
}

// Handle addition to the no entry list
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['no_entry_id'])) {
    $noEntryId = $_POST['no_entry_id'];
    try {
        $stmt = $pdo->prepare("INSERT INTO no_entry_list (IDNo, added_by, added_at) 
                               SELECT iv.IDNo, ?, NOW() 
                               FROM reports bv 
                               JOIN info_visitor iv ON bv.visitor_id = iv.Serial 
                               WHERE bv.report_id = ?");
        $stmt->execute([$user['username'], $noEntryId]);
        $displayError = "Visitor added to the no entry list.";
    } catch (PDOException $ex) {
        $displayError = "Error: " . $ex->getMessage();
    }
}

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Visitor Management</title>
    <link rel="stylesheet" href="BootStrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
    <link rel="stylesheet" type="text/css" href="navbar3.css">
    <script src="BootStrap/js/jQuery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" />
    <!-- Custom styles -->
    <link rel="stylesheet" href="../../assets/css/style.css">
    <script src="BootStrap/js/bootstrap.min.js"></script>
    <style>
        .form-container {
            max-height: 400px;
            overflow-y: auto;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="../dashboard.php" id="li"><?php echo $_SESSION['user']['username']; ?></a>
            </div>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="front.php" id="li">Home</a></li>
                <li><a href="myform.php">Add Visitor</a></li>
                <li><a id="li" href="logoutform.php">Checked Out Visitors</a></li>
                <li><a id="li" href="query_data.php">View Data</a></li>
                <li><a id="li" href="view_reported_visitors.php">Reported Visitors</a></li>
                <li><a id="li" href="report_visitor.php">Report Visitor</a></li>
                <li><a id="li" href="view_noentry_list.php">No Entry Visitors</a></li>
                <li><a id="li" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <h2>Reported Visitors</h2>
        <?php if ($displayError) : ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($displayError); ?></div>
        <?php endif; ?>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Visitor Name</th>
                    <th>ID No</th>
                    <th>Contact</th>
                    <th>Purpose</th>
                    <th>Reason for Reporting</th>
                    <th>Reported By</th>
                    <th>Reported At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($reportedVisitors)) : ?>
                    <tr>
                        <td colspan="9">No reported visitors found.</td>
                    </tr>
                <?php else : ?>
                    <?php foreach ($reportedVisitors as $visitor) : ?>
                        <tr>
                            <td><?php echo htmlspecialchars($visitor['report_id']); ?></td>
                            <td><?php echo htmlspecialchars($visitor['Name']); ?></td>
                            <td><?php echo htmlspecialchars($visitor['IDNo']); ?></td>
                            <td><?php echo htmlspecialchars($visitor['Contact']); ?></td>
                            <td><?php echo htmlspecialchars($visitor['Purpose']); ?></td>
                            <td><?php echo htmlspecialchars($visitor['reason']); ?></td>
                            <td><?php echo htmlspecialchars($visitor['reported_by']); ?></td>
                            <td><?php echo htmlspecialchars($visitor['reported_at']); ?></td>
                            <td>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="no_entry_id" value="<?php echo htmlspecialchars($visitor['report_id']); ?>">
                                    <button type="submit" class="btn btn-danger">Add to No Entry List</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>

</html>
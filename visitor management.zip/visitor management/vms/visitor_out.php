<?php
// Define your database connection parameters
include_once('../../config.php');
require_once '../middleware.php';
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['logout']) && isset($_POST['rid'])) {
        $rid = $_POST['rid'];

        // Check if the visitor exists and is online
        $checkSql = "SELECT * FROM info_visitor WHERE ReceiptID = :rid AND Status = 'ONLINE'";
        $checkStmt = $pdo->prepare($checkSql);
        $checkStmt->bindParam(":rid", $rid, PDO::PARAM_INT);
        $checkStmt->execute();

        if ($checkStmt->rowCount() > 0) {
            // Visitor exists and is online, update their status to 'OFFLINE'
            $updateSql = "UPDATE info_visitor SET Status = 'OFFLINE' WHERE ReceiptID = :rid";
            $updateStmt = $pdo->prepare($updateSql);
            $updateStmt->bindParam(":rid", $rid, PDO::PARAM_INT);

            if ($updateStmt->execute()) {
                $success = 1; // Set success flag
            } else {
                $displayError = "Error updating visitor status.";
            }
        } else {
            $displayError = "Visitor not found or already checked out.";
        }
    }
}

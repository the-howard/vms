<?php
// Enable error reporting
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

include_once('../../config.php');
include_once('visitor_out.php');

session_start();
$user = $_SESSION["user"];

/*if ($_SESSION["loggedIn"] == 0) {
header("location: index.php");
}*/

$tody = date("Y-m-d");
$sql = "SELECT Name FROM info_visitor WHERE Date = :date";
$sqlOnline = "SELECT * FROM info_visitor WHERE Status = 'ONLINE' LIMIT 10";
$sqlRecent = "SELECT * FROM (SELECT * FROM info_visitor ORDER BY Serial DESC LIMIT 10) a ORDER BY Serial DESC";

$resultToday = $pdo->prepare($sql);
$resultToday->bindParam(":date", $tody, PDO::PARAM_STR);
$resultToday->execute();
$onlineVsitor = 0; // Initialize to 0

if ($resultToday) {
    $onlineVsitor = $resultToday->rowCount();
}

$resultS = $pdo->query($sqlOnline);
$resultResRecent = $pdo->query($sqlRecent);

$displayError = '';
$success = 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['logout']) && isset($_POST['rid'])) {
        // Get the Receipt ID from the form
        $rid = $_POST['rid'];

        // Check if the visitor exists and is online
        $checkSql = "SELECT * FROM info_visitor WHERE ReceiptID = :rid AND Status = 'ONLINE'";
        $checkStmt = $pdo->prepare($checkSql);
        $checkStmt->bindParam(":rid", $rid, PDO::PARAM_INT);
        $checkStmt->execute();

        if ($checkStmt->rowCount() > 0) {
            // Visitor exists and is online, update their status to 'OFFLINE'
            $updateSql = "UPDATE info_visitor SET Status = 'OFFLINE' WHERE ReceiptID = :rid";
            $updateStmt = $pdo->prepare($updateSql);
            $updateStmt->bindParam(":rid", $rid, PDO::PARAM_INT);

            if ($updateStmt->execute()) {
                $success = 1; // Set success flag
            } else {
                $displayError = "Error updating visitor status.";
            }
        } else {
            $displayError = "Visitor successfully checked out.";
        }
    }
}
?>

<!DOCTYPE HTML5>
<html>

<head>
    <link rel="stylesheet" href="BootStrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
    <link rel="stylesheet" type="text/css" href="navbar3.css">
    <script src="BootStrap/js/jQuery.min.js"></script>
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" />
    <!-- Custome styles -->
    <link rel="stylesheet" href="../../assets/css/style.css">
    <script src="BootStrap/js/bootstrap.min.js"></script>
    <script>
    function printBadge() {
        // Check if user is on reported visitors list
        if (window.location.href.includes("view_reported_visitors.php")) {
            alert("Visitor is on reported list! Grant entry under supervision.");
        } else if (window.location.href.includes("view_noentry_list.php")) {
            alert("Visitor is on no entry list! Do not grant entry.");
        } else {
            // Clone the badge content to a new window for printing
            var printContents = document.getElementById("badge-content").innerHTML;
            var originalContents = document.body.innerHTML;
            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
            location.reload();
        }
    }
    </script>

</head>

<body>


    <!-- Navigation Menu -->
    <nav class="navbar navbar-default hide-from-printer">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="../dashboard.php" id="li">
                    <?php echo $_SESSION['user']['username']; ?>
                </a>
            </div>
            <ul class="nav navbar-nav navbar-right">

                <li><a href="front.php" id="li">Home</a></li>
                <li><a href="myform.php">Add Visitor</a></li>
                <li><a id="li" href="logoutform.php">Checked Out Visitors</a></li>
                <li><a id="li" href="query_data.php">View Data</a></li>
                <li><a id="li" href="view_reported_visitors.php">Reported Visitors</a></li>
                <li><a id="li" href="report_visitor.php">Report Visitor</a></li>
                <li><a id="li" href="view_noentry_list.php">No Entry Visitors</a></li>
                <li><a id="li" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="row">
        <div class="col-sm-3 hide-from-printer" style="padding-left:50px;height:100%;">
            <div class=" hide-from-printer">
                <h3>Check Out Visitor</h3>
            </div>
            <div style="padding-top:20px;display:block;">
                <form method="POST" action="">
                    <div class="form-group">
                        <label class="control-label" id="t" for="recept_id">Receipt ID :</label>
                        <input class="form-control" name="rid" type="number" placeholder="Enter Receipt ID." required />
                    </div>
                    <input id="x" name="logout" value="Checkout" type="submit"
                        onclick='return confirm("Are you sure you want to Checkout?")'>
                    <?php
                    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                        if ($success == 1)
                            echo "<span style='color:green;'>Checked out successfully!</span>";
                        elseif (!empty($displayError))
                            echo "<span style='color:red;'><br><br>$displayError</span>";
                    }
                    ?>
                </form><br>
            </div>
        </div>

        <div class="col-sm-5 hide-from-printer" style="padding-left: 50px;">
            <h3 style="padding-left:10px;text-align:center;">Details</h3>

            <?php
            $showResultFor = 0;
            if (isset($_GET['rid'])) {
                $showResultFor = $_GET['rid'];
            }
            $query = "SELECT * FROM info_visitor WHERE ReceiptID = :receiptId AND Status = 'ONLINE'";
            $getresult = $pdo->prepare($query);
            $getresult->bindParam(":receiptId", $showResultFor, PDO::PARAM_INT);
            $getresult->execute();
            $resultDetails = $getresult->fetch(PDO::FETCH_ASSOC);
            if ($resultDetails) { ?>
            <div id="badge-content">
                <span id="col-1" name="main">&nbsp;
                    <p style="width: 678px;" id="col-1">
                        <b>Date : </b><?php echo $resultDetails['Date']; ?>&nbsp;&nbsp; <b>Time in :</b>&nbsp;
                        <?php echo $resultDetails['TimeIN']; ?>
                    </p>
                    <span id="col-1" name="main"><b>Name :</b>&nbsp;
                        <?php echo $resultDetails['Name']; ?>
                    </span><br>

                    <span id="col-1"><b>Contact No :</b>&nbsp;
                        <?php echo $resultDetails['Contact'] ?>
                    </span><br>

                    <span id="col-1"><b>Purpose :</b>&nbsp;
                        <?php echo $resultDetails['Purpose']; ?>
                    </span><br>

                    <span id="col-1"><b>Meeting :</b>&nbsp;
                        <?php echo $resultDetails['meetingTo']; ?>
                    </span><br>

                    <span id="col-1"><b>Receipt ID :</b>&nbsp;
                        <?php echo $resultDetails['ReceiptID']; ?>
                    </span><br>

                    <span id="col-1"><b>From:</b>&nbsp;
                        <?php echo $resultDetails['Comment']; ?>
                    </span><br>

                    <span id="col-1"><b>Served by :</b>&nbsp;
                        <?php echo $_SESSION['user']['username']; ?>
                    </span>
                </span>
            </div>
            <br><br>
            <button type="button" id="print-button" class="btn btn-primary hide-from-printer"
                onclick="printBadge()">Print Badge</button>
            <a type="button" id="back-button" class="btn btn-secondary hide-from-printer" href="front.php">Back</a>
            <?php } ?>
        </div>

        <div class="col-sm-4" style="height:100%;">
            <h3 style="margin-right:auto;padding-left:40px;">Recent Visitors :&nbsp;
                <?php echo $onlineVsitor; ?>
            </h3>
            <ul class="list-group" style="width:80%;padding-top:20px;">
                <script>
                $(document).ready(function() {
                    $('[data-toggle="popover"]').popover({
                        container: 'body'
                    });
                });
                </script>
                <?php
                while ($result2 = $resultS->fetch(PDO::FETCH_ASSOC))
                    echo '<div  style = "padding-right:45px;padding-left:20px;">
                    <li class = "list-group-item" style="height :30px;padding-top:3px;"> 
                    <a style = "font-size:15px;"  href="front.php?rid=' . $result2['ReceiptID'] . '" data-html="true"  
                    title="<b>' . $result2['Name'] . '<b>" data-toggle="popover" data-trigger="hover"
                    data-content="Contact : ' . $result2['Contact'] . ' <br>Time in : ' . $result2['TimeIN'] . ' 
                    <br>Purpose : ' . $result2['Purpose'] . '
                    <br> R ID : ' . $result2['ReceiptID'] . '">' . $result2['Name'] . '</a>
                    </li>
                    </div>';
                ?>
            </ul>
        </div>
    </div>
</body>

</html>
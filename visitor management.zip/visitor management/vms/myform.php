<?php
//error_reporting(E_ALL);
//ini_set('display_errors', 1);
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../middleware.php';

session_start(); // Start the session

$user = $_SESSION['user'] ?? null;

$displayError = ''; // Initialize the error message

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and sanitize input data
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $IDNo = filter_input(INPUT_POST, 'IDNo', FILTER_SANITIZE_STRING);
    $cno = filter_input(INPUT_POST, 'cno', FILTER_SANITIZE_STRING);
    $p = filter_input(INPUT_POST, 'purpose', FILTER_SANITIZE_STRING);
    $comment = filter_input(INPUT_POST, 'comment', FILTER_SANITIZE_STRING);
    $meet = filter_input(INPUT_POST, 'MeetingTo', FILTER_SANITIZE_STRING);
    $personToVisit = $_POST["personToVisit"] ?? null;
    $contactPersonToVisit = $_POST["contactPersonToVisit"] ?? null;
    $designationPersonToVisit = $_POST["designationPersonToVisit"] ?? null;

    // Handle Base64 photo data
    $photoData = $_POST['photo'] ?? null;
    $photoPath = null;
    $uploadDir = 'uploads/';

    // Ensure the directory exists and is writable
    if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true)) {
        $displayError = "Error: Unable to create upload directory.";
    }

    if ($photoData) {
        // Process and save photo
        $photoPath = $uploadDir . uniqid() . '.png';
        $photoData = str_replace('data:image/png;base64,', '', $photoData);
        $photoData = str_replace(' ', '+', $photoData);
        $photoDecoded = base64_decode($photoData);
        
        if (!file_put_contents($photoPath, $photoDecoded)) {
            $displayError = "Error: Failed to save the photo.";
            $photoPath = null;
        }
    } else {
        $displayError = "Photo is required.";
    }

    // Validation
    if (empty($name) || empty($IDNo) || empty($p) || strlen($cno) < 9 || strlen($cno) > 13 || !$photoPath) {
        $displayError = "Please fill in all required fields and provide a photo.";
    } else {
        // Check if the visitor is on the entry list
        $stmt = $pdo->prepare("SELECT IDNo FROM no_entry_list WHERE IDNo = ?");
        $stmt->execute([$IDNo]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            $displayError = "Visitor is on the no entry list and cannot be registered!";
        } else {
            try {
                // Generate a unique ticket ID based on date and a random number
                $ticketId = date("Ymd") . rand(100000, 999999);

                // Use prepared statements to insert data
                $stmt = $pdo->prepare("INSERT INTO info_visitor (Name, IDNo, Contact, Purpose, meetingTo, day, month, year, Date,
        TimeIN, ReceiptID, Status, Comment, registeredBy, personToVisit, contactPersonToVisit, designationPersonToVisit,
        photoPath) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                
                if ($stmt) {
                    $date = date("Y/m/d");
                    $timein = date("H:i:s");
                    $day = date("d");
                    $month = date("m");
                    $year = date("Y");
                    $user_ = $user; // Use the session user

                    // Create variables for the values to be bound
                    $status = 'ONLINE';

                    $stmt->execute([$name, $IDNo, $cno, $p, $meet, $day, $month, $year, $date, $timein, $ticketId, $status, $comment, $user_, $personToVisit, $contactPersonToVisit, $designationPersonToVisit, $photoPath]);
                    
                    header('Location: user_profile.php');
                    exit;
                } else {
                    $displayError = "Error: Prepare statement failed.";
                }
            } catch (PDOException $ex) {
                $displayError = "Error: " . $ex->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="BootStrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
    <script src="BootStrap/js/jQuery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" />
    <!-- Custome styles -->
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="../../assets/css/form.css">

    <script src="BootStrap/js/bootstrap.min.js"></script>
    <style>

    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            display_ct(); // Start displaying time and date

            // Show additional fields based on purpose selection
            $('#purpose').on('change', function() {
                var purpose = $(this).val();
                $('.additional-fields').toggle(purpose === 'Personal');
            });

            // Open camera and take photo functions
            $('#openCameraBtn').on('click', startCamera);
            $('#closeCameraBtn').on('click', closeCamera);
            $('#takePhotoBtn').on('click', takePhoto);

            // Check visitor's ID against entry list when typing
            $('#IDNo').on('input', function() {
                var IDNo = $(this).val();
                checkLists(IDNo);
            });
        });

        function display_ct() {
            var date = new Date();
            var hours = date.getHours() > 12 ? date.getHours() - 12 : date.getHours();
            var am_pm = date.getHours() >= 12 ? "PM" : "AM";
            hours = hours < 10 ? "0" + hours : hours;
            var minutes = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
            var seconds = date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds();
            var time = hours + ":" + minutes + ":" + seconds + " " + am_pm;
            $('#t1').text(time);

            var dateString = (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear();
            $('#t2').text(dateString);

            setTimeout(display_ct, 1000);
        }

        function toggleAdditionalFields() {
            var purpose = $('#purpose').val();
            $('.additional-fields').toggle(purpose === 'Personal');
        }

        function startCamera() {
            navigator.mediaDevices.getUserMedia({
                    video: true
                })
                .then(function(stream) {
                    $('#video')[0].srcObject = stream;
                    $('#video')[0].play();
                });
            $('#takePhotoBtn, #closeCameraBtn').show();
            $('#openCameraBtn').hide();
        }

        function closeCamera() {
            var video = $('#video')[0];
            var stream = video.srcObject;
            var tracks = stream.getTracks();
            tracks.forEach(function(track) {
                track.stop();
            });
            video.srcObject = null;
            $('#takePhotoBtn, #closeCameraBtn').hide();
            $('#openCameraBtn').show();
        }

        function takePhoto() {
            var video = $('#video')[0];
            var canvas = $('#canvas')[0];
            var context = canvas.getContext('2d');

            context.drawImage(video, 0, 0, canvas.width, canvas.height);
            var dataURL = canvas.toDataURL('image/png');
            $('#photo').val(dataURL);

            $('#photo-preview').attr('src', dataURL).show();
            video.style.display = 'none';
            $('#takePhotoBtn, #closeCameraBtn').hide();
        }

        function checkLists(IDNo) {
            $.ajax({
                url: 'check_no_entry_list.php',
                method: 'POST',
                data: {
                    IDNo: IDNo
                },
                success: function(response) {
                    if (response === 'found') {
                        alert('Visitor is on the no entry list!');
                    }
                }
            });

            $.ajax({
                url: 'check_reported_list.php',
                method: 'POST',
                data: {
                    IDNo: IDNo
                },
                success: function(response) {
                    if (response === 'found') {
                        alert('Visitor is on the reported list!');
                    }
                }
            });
        }
    </script>

</head>

<body>

    <!-- Visitor Navigation Menu -->
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="../dashboard.php" id="li">
                    <?php echo $_SESSION['user']['username']; ?>
                </a>
            </div>
            <ul class="nav navbar-nav navbar-right">
                <!-- Time and date script -->
                <div style="float:right; padding-right:8px;padding-top:10px;">
                    <p id="timeDisplay" style="color: green;"> Time : <span id="t1"></span></p>
                    <p id="dateDisplay" style="color: green;"> Date : <span id="t2"></span></p>
                </div>
                <li><a href="front.php" id="li">Home</a></li>
                <li><a href="myform.php">Add Visitor</a></li>
                <li><a id="li" href="logoutform.php">Checked Out Visitors</a></li>
                <li><a id="li" href="query_data.php">View Data</a></li>
                <li><a id="li" href="view_reported_visitors.php">Reported Visitors</a></li>
                <li><a id="li" href="report_visitor.php">Report Visitor</a></li>
                <li><a id="li" href="view_noentry_list.php">No Entry Visitors</a></li>
                <li><a id="li" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>


    <div class="container">
        <div class="box">
            <div>
                <div style="margin-left:110px;padding-bottom:12px">
                    <h2>Add Visitor</h2>
                </div>
                <div class=" form-container">
                   <form class="myForm" action="myform.php" method="POST" id="form" enctype="multipart/form-data">

                        <?php echo $displayError; ?>
                        <div class="row">
                            <div class="col-sm-7">
                                <div class="form-group">
                                    <label for="IDNo">ID No. :</label>
                                    <input autocomplete="off" class="form-control" type="text" name="IDNo" id="IDNo" placeholder="Enter Visitor's ID No.">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-7">
                                <div class="form-group">
                                    <label for="name"> Name of visitor:</label>
                                    <input autocomplete="off" class="form-control" type="text" name="name" placeholder="Enter Visitor's Name." required id="name" oninvalid="this.setCustomValidity(this.willValidate?'':'Name is required')" onblur="isEmpty('name')" onfocus="onfo('name')" data-toggle="popover" title="Popover Header" data-content="Some content inside the popover" data-trigger="onfocus" />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-7">
                                <div class="form-group">
                                    <label for="cno"> Contact No. :</label> <span id="span" style="padding-bottom: 5px;float:right;"></span>
                                    <input autocomplete="off" class="form-control" type="text" id="MobileNumber" name="cno" placeholder="Enter Mobile Number (e.g., +2541234567890)" required pattern="^\+\d{1,4}\d{9,13}$" oninvalid="this.setCustomValidity(this.willValidate?'Enter a valid mobile number with country code (e.g., +2541234567890)':'')" oninput="setCustomValidity('')" data-toggle="popover" title="Popover Header" data-content="Some content inside the popover" data-trigger="onfocus" />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-7">
                                <div class="form-group">
                                    <label for="purpose">Purpose of visit:</label>
                                    <select class="form-control" name="purpose" id="purpose" required onchange="toggleAdditionalFields()">
                                        <option value="">Select Purpose</option>
                                        <option value="Official">Official</option>
                                        <option value="Personal">Personal</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row additional-fields">
                            <div class="col-sm-7">
                                <div class="form-group">
                                    <label for="personToVisit">Person to visit:</label>
                                    <input autocomplete="off" class="form-control" type="text" name="personToVisit" id="personToVisit" placeholder="Enter Person to Visit">
                                </div>
                            </div>
                        </div>
                        <div class="row additional-fields">
                            <div class="col-sm-7">
                                <div class="form-group">
                                    <label for="contactPersonToVisit">Contact of person to visit:</label>
                                    <input autocomplete="off" class="form-control" type="text" name="contactPersonToVisit" id="contactPersonToVisit" placeholder="Enter Contact of Person to Visit">
                                </div>
                            </div>
                        </div>
                        <div class="row additional-fields">
                            <div class="col-sm-7">
                                <div class="form-group">
                                    <label for="designationPersonToVisit">Designation of person to visit:</label>
                                    <input autocomplete="off" class="form-control" type="text" name="designationPersonToVisit" id="designationPersonToVisit" placeholder="Enter Designation of Person to Visit">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-7">
                                <div class="form-group">
                                    <label for="meetingTo">Office to visit:</label>
                                    <input autocomplete="off" class="form-control" type="text" required name="MeetingTo" id="meetingTo" placeholder="Which office are you visiting ?" oninvalid="this.setCustomValidity(this.willValidate?'':'Whom do you want to meet ?')" maxlength="30" onblur="isEmpty('meetingTo')" data-toggle="popover" title="Popover Header" data-content="Some content inside the popover" data-trigger="onfocus" />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-7">
                                <div class="form-group">
                                    <label for="comment">From:</label>
                                    <input autocomplete="off" class="form-control" type="text" maxlength="30" name="comment" id="comment" placeholder="Enter where visitor is from here" oninvalid="this.setCustomValidity(this.willValidate?'':'Please enter where visitor is from')" onblur="isEmpty('comment')" data-toggle="popover" title="From Information" data-content="Please provide any additional information where visitor is from" data-trigger="onfocus" />
                                </div>
                            </div>

                        </div>
                        <!-- New fields for photo capture -->
                        <div class="form-group">
                            <label class="control-label col-sm-2">Photo:</label>
                            <div class="col-sm-10">
                                <button type="button" id="openCameraBtn" class="btn btn-primary" onclick="startCamera()">Open
                                    Camera</button>
                                <button type="button" id="closeCameraBtn" class="btn btn-danger" onclick="closeCamera()">Close
                                    Camera</button>
                                <button type="button" id="takePhotoBtn" class="btn btn-success" onclick="takePhoto()">Take
                                    Photo</button>
                                <input type="hidden" id="photo" name="photo">
                                <video id="video"></video>
                                <canvas id="canvas" width="640" height="480"></canvas>
                                <img id="photo-preview" alt="Photo preview">
                            </div>
                        </div>
                        <div>
                            <input id="submitme" type="submit" name="submit_post" class="btn btn-success" value="Submit" onclick="return emptys()" />
                            <input autocomplete="off" id="mydata" type="hidden" name="mydata">
                        </div>
                    </form>
                </div>
            </div>
        </div>


        <!-- Slide Show Section -->
<div class="box">
     <div>
        <?php
        include '../../config.php';

        $sql = "SELECT * FROM wanted_people";
        $stmt = $pdo->query($sql);
        $people = $stmt->fetchAll(PDO::FETCH_ASSOC);
        ?>
        <div style="margin-left:110px;padding-bottom:12px">
            <h2>Wanted Persons.</h2>
        </div>
        <div class="slideshow-container">
            <div class="slides">
                <?php foreach ($people as $person) : ?>
                    <div class="card">
                        <a href="../wanted/person_detail.php?id=<?= $person['id'] ?>">
                            <img src="../wanted/images/<?= $person['image'] ?>" alt="<?= $person['name'] ?>">
                        </a>
                        <h3><?= $person['surname'] . ' ' . $person['first_name'] ?></h3>
                        <p>Gender: <?= $person['gender'] ?></p>
                        <p>ID/PP No.: <?= $person['id_pp_no'] ?></p>
                        <p>Place of Birth: <?= $person['place_of_birth'] ?></p>
                        <h3>Nationality</h3>
                        <p><?= $person['nationality'] ?></p>
                        <h3>Physical Description</h3>
                        <p>Height: <?= $person['height'] ?></p>
                        <p>Complexion: <?= $person['complexion'] ?></p>
                        <p>Color of Hair: <?= $person['hair_color'] ?></p>
                        <p>Color of Eyes: <?= $person['eye_color'] ?></p>
                        <p>Languages Spoken: <?= $person['languages_spoken'] ?></p>
                        <h3>Charges</h3>
                        <p><?= $person['charges'] ?></p>

                    </div>
                <?php endforeach; ?>
            </div>
            <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
            <a class="next" onclick="plusSlides(1)">&#10095;</a>
        </div>
    </div>
</div>

<script>
    let slideIndex = 0;
    const slides = document.querySelector('.slides');
    const totalSlides = document.querySelectorAll('.slides .card').length;

    const showSlides = () => {
        slides.style.transform = `translateX(${-slideIndex * 100}%)`;
    }

    const plusSlides = (n) => {
        slideIndex += n;
        if (slideIndex >= totalSlides) slideIndex = 0;
        if (slideIndex < 0) slideIndex = totalSlides - 1;
        showSlides();
    }

    const autoSlides = () => {
        slideIndex++;
        if (slideIndex >= totalSlides) slideIndex = 0;
        showSlides();
        setTimeout(autoSlides, 3000); // Change image every 3 seconds
    }

    document.addEventListener('DOMContentLoaded', () => {
        showSlides();
        setTimeout(autoSlides, 3000);
    });
</script>

    </div>
    <div class="footer">
        <p>&#169; Howard and Blackray ltd</p>
    </div>
</body>

</html>
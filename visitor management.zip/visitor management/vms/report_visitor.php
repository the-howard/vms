<?php
// Enable error reporting
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

include_once('../../config.php');
session_start();

$displayError = '';
$visitorDetails = null;
$receiptID = null;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['fetch'])) {
        $idno = trim($_POST['idno']);

        if (!preg_match('/^[0-9]{1,10}$/', $idno)) {
            $displayError = "Invalid ID number format";
        } else {
            try {
                $stmt = $pdo->prepare("SELECT * FROM info_visitor WHERE IDNo = ?");
                $stmt->bindParam(1, $idno, PDO::PARAM_INT);
                $stmt->execute();
                $visitorDetails = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$visitorDetails) {
                    $displayError = "Visitor not found with ID No: $idno";
                } else {
                    $receiptID = $visitorDetails['ReceiptID'];
                }
            } catch (PDOException $ex) {
                $displayError = "Error: " . $ex->getMessage();
            }
        }
    } elseif (isset($_POST['report'])) {
        $visitorID = $_POST['visitorID'];
        $reason = $_POST['reason'];
        $user = $_SESSION['user']['username'];

        try {
            $receiptID = isset($_POST['receiptID']) ? $_POST['receiptID'] : null;
            $visitor_IDNo = isset($_POST['visitor_IDNo']) ? $_POST['visitor_IDNo'] : null;

            $stmt = $pdo->prepare("INSERT INTO reports (visitor_id, receipt_id, reason, reported_by, visitor_IDNo) VALUES (?, ?, ?, ?, ?)");
            $stmt->bindParam(1, $visitorID);
            $stmt->bindParam(2, $receiptID);
            $stmt->bindParam(3, $reason);
            $stmt->bindParam(4, $user);
            $stmt->bindParam(5, $visitor_IDNo);
            if ($stmt->execute()) {
                echo "<script>alert('Visitor successfully reported'); window.location.href='view_reported_visitors.php';</script>";
                exit;
            } else {
                $displayError = "Error: Failed to report the visitor.";
            }
        } catch (PDOException $ex) {
            $displayError = "Error: " . $ex->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="BootStrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
    <link rel="stylesheet" type="text/css" href="navbar3.css">
    <script src="BootStrap/js/jQuery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" />
    <!-- Custom styles -->
    <link rel="stylesheet" href="../../assets/css/style.css">
    <script src="BootStrap/js/bootstrap.min.js"></script>
    <style>
        .container {
            max-height: 400px;
            overflow-y: auto;
        }
    </style>
</head>

<body>
    <!-- Navigation Menu -->
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="../dashboard.php" id="li">
                    <?php echo $_SESSION['user']['username']; ?>
                </a>
            </div>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="front.php" id="li">Home</a></li>
                <li><a href="myform.php">Add Visitor</a></li>
                <li><a id="li" href="logoutform.php">Checked Out Visitors</a></li>
                <li><a id="li" href="query_data.php">View Data</a></li>
                <li><a id="li" href="view_reported_visitors.php">Reported Visitors</a></li>
                <li><a id="li" href="report_visitor.php">Report Visitor</a></li>
                <li><a id="li" href="view_noentry_list.php">No Entry Visitors</a></li>
                <li><a id="li" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <h2>Report Visitor</h2>
        <?php if ($displayError) : ?>
            <div class="alert alert-danger"><?php echo $displayError; ?></div>
        <?php endif; ?>

        <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="POST">
            <div class="form-group">
                <label for="idno">ID No. :</label>
                <input autocomplete="off" class="form-control" type="text" name="idno" id="idno" placeholder="Enter Visitor's ID No." required>
            </div>
            <button type="submit" name="fetch" class="btn btn-primary">Fetch Visitor</button>
        </form>

        <?php if ($visitorDetails) : ?>
            <h3>Visitor Details</h3>
            <p>Name: <?php echo htmlspecialchars($visitorDetails['Name']); ?></p>
            <p>ID No: <?php echo htmlspecialchars($visitorDetails['IDNo']); ?></p>
            <p>Contact: <?php echo htmlspecialchars($visitorDetails['Contact']); ?></p>
            <p>Purpose: <?php echo htmlspecialchars($visitorDetails['Purpose']); ?></p>
            <p>Meeting To: <?php echo htmlspecialchars($visitorDetails['meetingTo']); ?></p>
            <p>Date: <?php echo htmlspecialchars($visitorDetails['Date']); ?></p>
            <p>Time In: <?php echo htmlspecialchars($visitorDetails['TimeIN']); ?></p>

            <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="POST">
                <input type="hidden" name="visitorID" value="<?php echo isset($visitorDetails['Serial']) ? htmlspecialchars($visitorDetails['Serial']) : ''; ?>">
                <input type="hidden" name="receiptID" value="<?php echo htmlspecialchars($receiptID); ?>">
                <input type="hidden" name="visitor_IDNo" value="<?php echo htmlspecialchars($visitorDetails['IDNo']); ?>">
                <div class="form-group">
                    <label for="reason">Reason for Reporting:</label>
                    <textarea name="reason" id="reason" class="form-control" required></textarea>
                </div>
                <button type="submit" name="report" class="btn btn-danger">Report Visitor</button>
            </form>
        <?php endif; ?>
    </div>
</body>

</html>
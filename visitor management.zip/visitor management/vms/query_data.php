<?php
// Enable error reporting
//error_reporting(E_ALL);
//ini_set('display_errors', 1);
include_once('../../config.php');

session_start();

$user = $_SESSION['user'];

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Visitor Management</title>
    <link rel="stylesheet" href="BootStrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
    <link rel="stylesheet" type="text/css" href="navbar3.css">
    <script src="BootStrap/js/jQuery.min.js"></script>
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" />
    <!-- Custom styles -->
    <link rel="stylesheet" href="../../assets/css/style.css">
    <script src="BootStrap/js/bootstrap.min.js"></script>
    <style>
    body {
        width: 100%;
        overflow-x: hidden;
        position: relative;
        height: auto;
        background-color: #f8f9fa;
    }

    #body {
        padding: 30px;
    }

    table {
        border-collapse: collapse;
        width: 100%;
    }

    th,
    td {
        padding: 15px;
        text-align: left;
        border: 1px solid #ddd;
    }

    th {
        background-color: #f2f2f2;
    }

    .affix {
        top: 0;
        width: 100%;
        z-index: 9999 !important;
    }

    .FormLabel {
        padding-top: 20px;
    }

    .FormLabel input[type="radio"] {
        float: right;
    }

    #button {
        padding-top: 20px;
    }

    .custom-div-style {
        border-right: solid 3px;
        height: 85%;
        margin-bottom: 40px;
        background-color: whitesmoke;
        float: left;
        color: black;
        padding: 20px;
    }

    .body {
        max-height: auto;
        overflow-y: auto;
    }

    .scroll-container {
        max-height: 600px;
        overflow-y: auto;
        padding-left: 0;
    }

    .thumbnail {
        width: 200px;
        border: 1px solid #ddd;
        border-radius: 4px;
        padding: 10px;
        margin: 15px;
        background-color: #fff;
    }

    .thumbnail img {
        width: 100%;
        height: auto;
        border-radius: 4px;
    }

    .navbar-brand {
        font-weight: bold;
    }

    h2 {
        font-size: 1.5em;
        margin-bottom: 20px;
    }

    .btn-success {
        margin-top: 20px;
    }
    </style>
</head>

<body>
    <!-- Admin Navigation Menu -->
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="../dashboard.php" id="li">
                    <?php echo $_SESSION['user']['username']; ?>
                </a>
            </div>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="front.php" id="li">Home</a></li>
                <li><a href="myform.php">Add Visitor</a></li>
                <li><a id="li" href="logoutform.php">Checked Out Visitors</a></li>
                <li><a id="li" href="query_data.php">View Data</a></li>
                <li><a id="li" href="report_visitor.php">Report Visitor</a></li>
                <li><a id="li" href="view_reported_visitors.php">View Reported Visitors</a></li>
                <li><a id="li" href="view_noentry_list.php">No Entry Visitors</a></li>
                <li><a id="li" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>
    <div id='body' class="body">
        <div class="row" style="padding-bottom: 40px;height: auto;margin-left: -30px;">

            <div class="col-sm-2 custom-div-style">

                <script>
                function undisable() {
                    document.getElementById("dateF").disabled = false;
                    document.getElementById("dateP").disabled = false;
                }

                function disable() {
                    document.getElementById("dateF").disabled = true;
                    document.getElementById("dateP").disabled = true;
                }
                </script>
                <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="POST" style="padding-top:20px;">

                    <div class="FormLabel" style="border-top: solid 2px;">
                        <label for="all">View All Entries :</label><input type="radio" id="allData" name="search"
                            value="all" onclick="disable()">
                    </div>
                    <div class="FormLabel" style="border-top: solid 2px;">
                        <label for="active entries">View all Active Visitors : </label><input type="radio" name="search"
                            id="active" value="active" onclick="disable()">
                    </div>
                    <div style="border-bottom: solid 2px;padding-bottom: 12px;">
                        <div class="FormLabel" style="border-top: solid 2px;">
                            <label for="date">Search By Date :</label> <input type="radio" id="bydate" name="search"
                                value="dates" onclick="undisable()">
                        </div>


                        <div>

                            <input type="date" id="dateP" name="dateP" value="<?php if (isset($datePF)) {
                                                                                    echo $datePF;
                                                                                } ?>" id="in1" oninput="onDateInput()"
                                disabled required />
                            <input type="date" id="dateF" name="dateF" value="<?php if (isset($dateFP)) {
                                                                                    echo $dateFP;
                                                                                } ?>" id="in2" disabled required />

                        </div>
                    </div>
                    <script type="text/javascript">
                    function onDateInput() {
                        var inputDateA = document.getElementById('in1').value;

                        if (inputDateA)
                            document.getElementById('in2').setAttribute('min', inputDateA);

                    }
                    </script>

                    <script type="text/javascript">
                    var dateInput = document.getElementById('in1');
                    var dateInput2 = document.getElementById('in2');

                    if (dateInput.value != "" || dateInput2.value != "")
                        document.getElementById('inputdate').removeAttribute("class");
                    </script>
                    <div id="button">
                        <button type="submit" name="submit" class="btn btn-success"><span
                                class="glyphicon glyphicon-search"></span>&nbsp;Search
                        </button>
                    </div>
                </form>
            </div>

            <div class="col-sm-10">
                <?php
                if ($_SERVER["REQUEST_METHOD"] == "POST") {

                    if (!isset($_POST["search"])) {
                        echo "<br><br><span style='color : red;'>Please select any field !</span>";
                        exit();
                    }

                    /*-----------------------------------DISPLAYING ALL DATA------------------------------------------*/

                    if (isset($_POST["search"]) && $_POST["search"] == "all") {

                        try {
                            // Database connection setup
                            $dsn = "mysql:host=$host;dbname=$dbname";
                            $pdo = new PDO($dsn, $username, $password);

                            // Fetch all records from the table
                            $query = "SELECT * FROM info_visitor";
                            $stmt = $pdo->prepare($query);
                            $stmt->execute();
                            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                            $count = count($result);

                            // Displaying fetched records
                            if ($count) {
                                echo "<br>
                <h3 style='padding-left: 16px;'>Information of all visitors :</h3><br />";
                                displayVisitors($result);
                            } else {
                                echo "<br><span style='color : red;'>No Entries to Display</span>";
                            }
                        } catch (PDOException $e) {
                            echo 'Error: ' . $e->getMessage();
                        }
                    }

                    /* -----------------------------------DISPLAY ACTIVE VISITORS------------------------------------*/ else
                if (isset($_POST["search"]) && $_POST["search"] == "active") {
                        try {
                            $dsn = "mysql:host=$host;dbname=$dbname";
                            $pdo = new PDO($dsn, $username, $password);
                            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                            $sql = "SELECT * FROM info_visitor WHERE Status = 'ONLINE'";
                            $stmt = $pdo->prepare($sql);
                            $stmt->execute();
                            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                            $count = count($result);

                            if ($count) {
                                echo "<br>
                <h3 style='padding-left: 16px;'>Visitor Information for Active Visitors :</h3><br />";
                                displayVisitors($result);
                            } else {
                                echo "<br><span style='color : red;'>No Entry Found !</span>";
                            }
                        } catch (PDOException $e) {
                            echo 'Error: ' . $e->getMessage();
                        }
                    }


                    /*-------------------------DISPLAYING SELECTED DATA--------------------------------------------------*/ else if (isset($_POST["search"]) && $_POST["search"] == "dates") {
                        if (empty($_POST["dateP"]) || empty($_POST["dateF"])) {
                            echo "<br><br><span style='color : red;'>Select a valid option</span>";
                        } else {
                            // Retrieving input dates
                            $datePF = $_POST['dateP'];
                            $dateFP = $_POST['dateF'];
                            $dateP = explode('-', $_POST['dateP']);
                            $dateF = explode('-', $_POST['dateF']);
                            $day_start = $dateP[2];
                            $day_end = $dateF[2];
                            $month_start = $dateP[1];
                            $month_end = $dateF[1];
                            $year_start = $dateP[0];
                            $year_end = $dateF[0];

                            // Forming SQL query for date range search
                            $sql = "SELECT * FROM info_visitor WHERE Date BETWEEN '$year_start-$month_start-$day_start' AND
                '$year_end-$month_end-$day_end'";

                            try {
                                // Database connection setup
                                $dsn = "mysql:host=$host;dbname=$dbname";
                                $pdo = new PDO($dsn, $username, $password);
                                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                                // Execute SQL query
                                $stmt = $pdo->prepare($sql);
                                $stmt->execute();
                                $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                $count = count($result);

                                // Displaying fetched records
                                if ($count) {
                                    if ($day_start == $day_end && $month_start == $month_end && $year_start == $year_end) {
                                        echo "<br>
                <h3 style='padding-left: 16px;'>Visitor Information for $day_start-$month_start-$year_start</h3>";
                                    } else {
                                        echo "<br>
                <h3 style='padding-left: 16px;'>Visitor Information from $day_start-$month_start-$year_start to
                    $day_end-$month_end-$year_end</h3>";
                                    }
                                    displayVisitors($result);
                                } else {
                                    echo "<br><br><span style='color : red;'>No Match Found Sorry</span>";
                                }
                            } catch (PDOException $e) {
                                echo 'Error: ' . $e->getMessage();
                            }
                        }
                    }
                }

                function displayVisitors($result)
                {
                    foreach ($result as $row) {
                        echo '<div class="col-sm-2">
                    <div class="thumbnail" style="width:175px;">
                        <p style="text-align:center;"><strong>' . $row['Name'] . ' </strong></p>';
                        if (isset($row['photoPath'])) {
                            echo '<img src="' . $row['photoPath'] . '" alt="Photo of ' . $row['Name'] . '"
                            style="width:150px;height:150px;">';
                        } else {
                            echo '<img src="uploads/default.png" alt="No photo available"
                            style="width:150px;height:150px;">';
                        }
                        echo '<p>ID No.: ' . $row['IDNo'] . '</p>
                        <p>Receipt ID : ' . $row['ReceiptID'] . '</p>
                        <p>Contact : ' . $row['Contact'] . '</p>
                        <p>Time In : ' . $row['TimeIN'] . '</p>
                        <p>Date : ' . $row['Date'] . '</p>
                        <p>Purpose : ' . $row['Purpose'] . '</p>
                        <p>Meeting : ' . $row['meetingTo'] . '</p>
                        <p>Person to Visit : ' . $row['personToVisit'] . '</p>
                        <p>Contact of Person to Visit : ' . $row['contactPersonToVisit'] . '</p>
                        <p>Designation of Person to Visit : ' . $row['designationPersonToVisit'] . '</p>
                        <p>Status : ' . $row['Status'] . '</p>
                        <p>Comment : ' . $row['Comment'] . '</p>
                    </div>
                </div>';
                    }
                }

                ?>

            </div>
        </div>
    </div>
</body>

</html>
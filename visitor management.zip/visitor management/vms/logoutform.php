<?php

// Enable error reporting
//error_reporting(E_ALL);
//ini_set('display_errors', 1);
include_once('../../config.php');
require_once '../middleware.php';
session_start();

include_once('visitor_out.php');

/*$user = $_SESSION['user'];

if ($_SESSION["loggedIn"] == 0) {
    header("location: index.php");
    exit;
}*/

?>

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="BootStrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
    <link rel="stylesheet" type="text/css" href="navbar3.css">
    <script src="BootStrap/js/jQuery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" />
    <!-- Custome styles -->
    <link rel="stylesheet" href="../../assets/css/style.css">
    <script src="BootStrap/js/bootstrap.min.js"></script>
</head>

<body>
    <!-- Admin Navigation Menu -->
    <?php //include_once(INCLUDE_PATH . "/layouts/admin_navbar.php") 
    ?>
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="#" id="lii">
                    <?php echo $_SESSION['user']['username']; ?>
                </a>
            </div>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="front.php" id="li">Home</a></li>
                <li><a href="myform.php">Add Visitor</a></li>
                <li><a id="li" href="logoutform.php">Checked Out Visitors</a></li>
                <li><a id="li" href="query_data.php">View Data</a></li>
                <li><a id="li" href="view_reported_visitors.php">Reported Visitors</a></li>
                <li><a id="li" href="report_visitor.php">Report Visitor</a></li>
                <li><a id="li" href="view_noentry_list.php">No Entry Visitors</a></li>
                <li><a id="li" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>
    <div>
        <p>
        <h3 style="padding-left: 25px">The following visitors were Logged out today.</h3>
        </p><br>
    </div>
    <div class="row" style="padding-left: 25px">

        <?php
        $date = date("Y-m-d");
        $query = "SELECT * FROM info_visitor WHERE Date = :date AND Status = 'OFFLINE'";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':date', $date);
        $stmt->execute();

        while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo '<div class="col-sm-2">
                    <div class="thumbnail" style="width:175px;">
                        <p style="text-align:center;"><strong>' . $result['Name'] . ' </strong></p>
                        <p>Receipt ID : ' . $result['ReceiptID'] . '</p>
                        <p>Contact : ' . $result['Contact'] . '</p>
                        <p>Time In : ' . $result['TimeIN'] . '</p>
                        <p>Date    : ' . $result['Date'] . '</p>
                        <p>Meeting : ' . $result['meetingTo'] . '</p>
                    </div>
                </div>';
        }
        ?>
    </div>
</body>

</html>
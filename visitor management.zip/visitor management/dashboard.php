<?php include_once('../config.php') ?>
<?php include_once(ROOT_PATH . '/admin/middleware.php') ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Admin</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" />
    <!-- Custom styles -->
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>
    <?php include_once(INCLUDE_PATH . "/layouts/admin_navbar.php") ?>

    <div class="container admin-panel">
        <div class="col-md-4 col-md-offset-4">
            <h1>Admin</h1>
            <br />
            <ul class="list-group">
                <a href="<?php echo BASE_URL . 'admin/vms/myform.php' ?>" class="list-group-item">Manage Visitors</a>
                <a href="<?php echo BASE_URL . 'admin/users/userList.php' ?>" class="list-group-item">Manage Users</a>
                <a href="<?php echo BASE_URL . 'admin/roles/roleList.php' ?>" class="list-group-item">Manage Roles</a>
                <a href="<?php echo BASE_URL . 'admin/wanted/index.php' ?>" class="list-group-item">Manage Wanted
                    Persons</a>
            </ul>
        </div>
    </div>
    <?php include_once(INCLUDE_PATH . "/layouts/footer.php") ?>
</body>

</html>